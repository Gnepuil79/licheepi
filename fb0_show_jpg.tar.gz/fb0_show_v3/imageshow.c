#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <grp.h>
#include <stdlib.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <linux/fb.h>
#include <sys/ioctl.h>
#include <stdbool.h>
#include "jpeglib.h"
int main(int argc, char const *argv[])
{
	
	if (argc != 2)
	{
		printf("./可执行文件 <jpeg格式图片文件>\n");
		return -1;
	}

	//打开液晶屏
	int lcd_fd = open("/dev/fb0", O_RDWR);
	if (lcd_fd == -1)
	{
		perror("open");
		return -1;
	}

	//获取液晶屏信息
	struct fb_var_screeninfo vinfo;
	ioctl(lcd_fd, FBIOGET_VSCREENINFO, &vinfo); // 获取可变属性
	int lcd_w = vinfo.xres;
	int lcd_h = vinfo.yres;
	int lcd_b = vinfo.bits_per_pixel/8;
	printf("该液晶屏宽：%d，高：%d, 每个像素点%d个字节\n", lcd_w, lcd_h, lcd_b);

	//进行内存映射
	int *p = mmap(NULL, lcd_w * lcd_h * lcd_b, PROT_WRITE | PROT_READ, MAP_SHARED, lcd_fd, 0);
	if (p == (void *)-1)
	{
		perror("mmap");
		return -2;
	}

    // 刷黑屏幕
    memset(p, 0x00, 800 * 480 * 4); 

	//(1)为jpeg对象分配空间并初始化
	struct jpeg_decompress_struct cinfo;	//解压jpeg的对象结构体
	struct jpeg_error_mgr jerr;				//定义错误结构体
	
	cinfo.err = jpeg_std_error(&jerr);		//错误处理结构体绑定
	jpeg_create_decompress(&cinfo);			//初始化jpeg的对象结构体

	//(2)指定解压缩数据源
	FILE *infile = fopen(argv[1], "r+");
	if (infile == NULL)
	{
		perror("fopen jpeg");
		return -3;
	}
	jpeg_stdio_src(&cinfo, infile);//指定解压缩数据源

	//(3)获取文件信息
	jpeg_read_header(&cinfo, true);
	
	//(4)为解压缩设定参数，包括图像大小，颜色空间
	int n = 1;			//缩小倍数
	while(cinfo.image_width/n>lcd_w || cinfo.image_height/n>lcd_h)
	{
		n *= 2;
	}

	//设定的缩小倍数
	cinfo.scale_num = 1;		//分子
	cinfo.scale_denom = n;		//分母
	// cinfo.out_color_space = JCS_GRAYSCALE;	//颜色空间
	printf("width1:%d height1:%d\n", cinfo.image_width, cinfo.image_height);//设定之前的宽高

	//(5)开始解压缩
	jpeg_start_decompress(&cinfo);
	printf("width:%d height:%d\n", cinfo.output_width, cinfo.output_height);//设定解压缩之后的宽高

	//(6)取出数据（做相关的应用），安装一行一行去读取的
	//output_components像素点大小
	//申请能够存放一行数据的缓冲区
	int row_size = cinfo.output_width*cinfo.output_components;
	char *buffer = (char *)malloc(row_size);
	//output_scanline当前读取行数
	while(cinfo.output_scanline < cinfo.output_height)
	{
		//按行读取数据
		jpeg_read_scanlines(&cinfo, (JSAMPARRAY)&buffer, 1);
		//将读取到的一行数据进行显示
		int i = 0, j = 0;
		for (;j< cinfo.output_width; i+=3, j++)
		{
			//内存映射的方式
			*(p+(cinfo.output_scanline-1)*lcd_w + j) = buffer[i+0]<<16| buffer[i+1]<<8| buffer[i+2];
		}
	}

	//(7)解压缩完毕
	jpeg_finish_decompress(&cinfo);

	//(8)释放资源
	jpeg_destroy_decompress(&cinfo);
	munmap(p, lcd_w*lcd_h*lcd_b);
	close(lcd_fd);
	fclose(infile);
	free(buffer);

	return 0;
}

