/*
 * Copyright 2015 Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __FSL_SATA_H_
#define __FSL_SATA_H_

int ls1021a_sata_init(void);
#endif
